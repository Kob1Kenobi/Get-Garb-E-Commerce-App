package com.getgarb.kodekenobi.Prevalent;

import com.getgarb.kodekenobi.Model.Users;

public class Prevalent
{
    public static Users currentOnlineUser;

    public static final String UserPhoneKey="UserPhone";
    public static final String UserPasswordKey="UserPassword";
}
